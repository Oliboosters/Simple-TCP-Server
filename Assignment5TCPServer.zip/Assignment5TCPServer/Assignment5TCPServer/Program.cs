﻿using System;

namespace Assignment5TCPServer
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Worker pleaseWork = new Worker();
            pleaseWork.Start();
        }
    }
}
