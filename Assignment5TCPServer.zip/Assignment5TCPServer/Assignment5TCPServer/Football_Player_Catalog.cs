﻿using Assignment5TCPServer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Assignment5TCPServer
{
    public class Football_Player_Catalog
    {
        List<Football_Player> PlayerList;

        public Football_Player_Catalog(List<Football_Player> list)
        {
            PlayerList = list;
        }

        public void SavePlayer(Football_Player player)
        {
            Console.WriteLine($"The Player: {player.Name} has been saved!");
            PlayerList.Add(player);
        }

        public Football_Player GetPlayer(int id)
        {
            foreach (Football_Player p in PlayerList)
            {
                if (p.ID == id)
                {
                    return p;
                }
            }
            Console.WriteLine("Nothing was found!");
            return null;
        }

        public void GetAllPlayers()
        {
            string play;

            Console.WriteLine("All Football Players: \n");
            foreach (Football_Player p in PlayerList)
            {
                play = JsonSerializer.Serialize<Football_Player>(p);
                Console.WriteLine(play +"\n");
                //Console.WriteLine(p.ToString());
            }
        }
    }
}
