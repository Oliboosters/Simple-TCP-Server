﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5TCPServer.Models
{
    public class Football_Player
    {
        //Private Fields

        private string name;
        private int price;
        private int shirtNumber;

        //Class Proporties

        public int ID { get; set; } //Auto-generated Property

        public string Name
        {
            get { return name; }

            set
            {
                if (value.Length >= 4)
                {
                    name = value;
                }
                else throw new ArgumentOutOfRangeException();
            }
        }

        public int Price
        {
            get { return price; }

            set
            {
                if (value > 0)
                {
                    price = value;
                }
                else throw new ArgumentOutOfRangeException();
            }
        }

        public int ShirtNumber
        {
            get { return shirtNumber; }

            set
            {
                if (value >= 1 && value <= 100)
                {
                    shirtNumber = value;
                }
                else throw new ArgumentOutOfRangeException();
            }
        }

        //Constructor with Parameters

        public Football_Player(int _id, string _name, int _price, int _shirtNumber)
        {
            ID = _id;
            Name = _name;
            Price = _price;
            ShirtNumber = _shirtNumber;  
        }

        //Constructor without Parameters

        public Football_Player()
        {

        }

        public override string ToString()
        {
            return $"FootballPlayer Nr.{ShirtNumber} information! \nID: {ID} | Name: {Name} | Price: {Price}";
        }
    }
}
