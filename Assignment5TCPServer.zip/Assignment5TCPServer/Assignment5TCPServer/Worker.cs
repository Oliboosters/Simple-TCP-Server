﻿using Assignment5TCPServer.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Assignment5TCPServer
{
    public class Worker
    {
        private readonly List<Football_Player> serverList = new List<Football_Player>()
        {
            new Football_Player(1,"Jacky Jack", 120, 8),
            new Football_Player(2,"Bobby Bob", 89, 10),
            new Football_Player(3,"Freddy Fred", 109, 2),
            new Football_Player(4,"Freaky Frank", 300, 16)
        };

        public void Start()
        {
            Console.WriteLine("Welcome friend ^_^ Before we can begin, please input Port Nr. 2121 into your Socket-Test program!\n");
            TcpListener listener = new TcpListener(2121);
            listener.Start();

            while (true)
            {
                TcpClient socket = listener.AcceptTcpClient();

                Task.Run(
                    () => { DoClient(socket); }
                );             
            }        
        }
        private void DoClient(TcpClient socket)
        {
            using (StreamReader sr = new StreamReader(socket.GetStream()))
            using (StreamWriter sw = new StreamWriter(socket.GetStream()))
            {
                Console.WriteLine("Please input a option from the menu!\n");
                Console.WriteLine("1). Get All Players");
                Console.WriteLine("2). Get Player");
                Console.WriteLine("3). Save Player\n");

                sw.AutoFlush = true;

                Football_Player_Catalog catalog = new Football_Player_Catalog(serverList);

                String optionString = sr.ReadLine();

                switch(optionString.ToLower())
                {
                    case "get all players":

                        Console.WriteLine("Server has detected a request: (Get All Players)\n");

                        catalog.GetAllPlayers();

                        break;

                    case "get player":

                        Console.WriteLine("Server has detected a request: (Get Player)\nPlease input player object ID: ");
                        int getPlayerID = Convert.ToInt32(sr.ReadLine());

                        Football_Player playerResult = catalog.GetPlayer(getPlayerID);

                        //Console.WriteLine("Server has found a match!\n" + playerResult.ToString());

                        string play = JsonSerializer.Serialize<Football_Player>(playerResult);

                        Console.WriteLine("Server has found a match!\n" + play);

                        break;

                    case "save player":

                        Console.WriteLine("Server has detected a request: (Save Player)\nPlease input player object in json format: ");
                        String savePlayer = sr.ReadLine();

                        Football_Player player = JsonSerializer.Deserialize<Football_Player>(savePlayer);
                        catalog.SavePlayer(player);

                        break;
                }
            }
            socket?.Close();
        }
    }
}
